<?php
 //logica upravlenia putami
 $routes = [
   ''=>'HomeController@index',
    'catalog'=>'CatalogController@index',
   'products'=>'ProductController@index',
   'contacts'=>'ContactController@index',
   'seed'=>'TestController@seed',
     //user routes
     'signup' => 'UserController@signup',
     'signin' => 'UserController@signin',
     'signup-success'=>'UserController@signup-success',
     'signout' => 'UserController@signout',

 ];

//index.php?products
  //esli esti get zapros
  $path = '';
  if(!empty($_GET)){
   $path = array_keys($_GET)[0];

//  var_dump($path);
  }

  if(array_key_exists($path,$routes)){
//    print_r($routes);
  $action = explode('@',$routes[$path]);
//  print_r($action);
  $controller = $action[0];//name file controller
//  print_r($controller);
  $method = $action[1];
//  print_r($method);
  include './app/Controllers/'.$controller.'.php';

  if (!empty($_POST)){
      $controller::$method($_POST);

  } else {
      $controller::$method();

  }

//var_dump($action);
  }else{print "not found";}
 ?>
