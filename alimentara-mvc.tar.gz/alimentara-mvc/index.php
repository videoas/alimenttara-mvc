<?php

include './vendor/autoload.php';
 //error_reporting( E_ERROR );
// 1)bootstrap->   basic logica
//2) config   ->   setings
$loader = new Twig_Loader_Filesystem('./resources/views');
$twig = new Twig_Environment($loader, array(
  //  'cache' => '/path/to/compilation_cache',
));
function view($template,$data=[]){//чтобы не объявлять глобальную переменную
   global $twig;
   echo $twig->render($template.'.twig.html',$data);
}
//3)routes    ->
include './routes.php';
//   print "ok!";
?>
