<?php
use Rhumsaa\Uuid\Uuid;
use Rhumsaa\Uuid\Exception\UnsatisfiedDependencyException;


   trait GenUuid
   {

     //фрагмент общей логики для генерации классов
     public function generateId()
     {
       $this->id = Uuid::uuid1()->toString();
     }
   }


 ?>
