<?php

include 'app/Models/Product.php';
include 'app/Models/Category.php';
include 'app/Models/User.php';
include 'app/Models/Cart.php';

   class TestController
   {
     public static function index(){

     }
     public static function seed()
     {


       print "Generating data!";
////////////////////////random create new Product//////////////////////////////
       $faker = Faker\Factory::create();

       for ($i=0; $i < 6 ; $i++) {
         $p = new Product(
          $faker->sentence(6,true),
          $faker->randomNumber(3),
          [$faker->imageUrl($width = 300, $height = 400)],
          $faker->randomNumber(1)
                            );
         $p->save();
                                  }


////////////////////////////////clear //////////////////////////////////////////

       //Product::clearAll();
      //Category::clearAll();

////////////////////////////////new Product/////////////////////////////////////

     // $p1 = new Product('samsung',1000,['1.jpg'],10);
     //  $p1->save();

///////////////saving the category through the product id///////////////////////
      //    $p1 = Product::load('4e964104-9506-11e8-84bf-2cd44493775b');
      //    $c = new Category('mobiles') ;
      //    $c->save();
      //    print_r($c);
      //    $p1->addCategory($c);
///////////////////////////////////load categories//////////////////////////////
          $c = Category::load('9919e7b4-9513-11e8-9297-2cd44493775b');
          print_r($c);
////////////////////////////////////////////////////////////////////////////
  //   $c = Category::distribut();
    ///5-6 продуктов распределить по 3 категориям

        // $p1 = Product::load('dc464c7c-943b-11e8-8821-2cd44493775b');
        //  print_r( $p1);
      //  print $p1->getCategory()->name;

////////////////////////////////////////////////////////////////////////////////

   //$p =Product::load('2feea82e-941e-11e8-ae92-2cd44493775b');
   //print_r($p);
   //$p->delete();
  //$p->clearAll();
         }
     }
 ?>
