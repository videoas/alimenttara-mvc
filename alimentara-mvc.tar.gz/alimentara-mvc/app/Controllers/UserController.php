<?php

  include 'app/Models/User.php';

    class UserController
        {
            public static function signup($request=[])
            {


              $no_error ="";
              $error="";
              $data =$_POST;
              if (  isset($data['do_signup'])  )
               {

                if ( trim($data['login']) == '' )
                {
                $errors[]='Input Login';
                }
                if (trim($data['firstname']) == '')
                 {
                  $errors[]= 'Input Firstname';
                }
                if (trim($data['lastname']) == '')
                {
                  $errors[]= 'Input lastname';
                }
                if (trim($data['email']) == '')
                {
                  $errors[]= 'Input EMAIL';
                }
                if ($data['password'] == '')
                {
                  $errors[]= 'Input password';
                }
                if ($data['confirm_password'] != $data['password'])
                {
                  $errors[]= 'Confirm Password incorrect';
                }
                if (empty($errors))
                {
                  $user = new User(
                         $request['login'],
                         $request['password'],
                         $request['firstname'],
                         $request['lastname'],
                         $request['email'],
                         $request['password']
                  );
                  $user->save();
                  $no_error = "Regisration SUCCESS";
                }
                else
                {
                    $error = array_shift($errors);
                }


    }

    view('signup',


      [
         'no_error'  => $no_error,
         'error'     => $error,
         'login'     => $request['login'],
         'firstname' => $request['firstname'],
         'lastname'  => $request['lastname'],
         'email'     => $request['email']
       ]

    );
  }

}
            //  print_r($request[]);
              //print_r
            //  $request['login'] = $_POST['login'];
                //$name = 'test';

            //

                    // validation
                    // if not valid -> go to view('signup', ['error'=> ''...])
            //  print_r( [$request]);


                 //$_POST['login']=$request['login'];



                 //  возвращать данные введенные юзером и предлагать исправить
                    //input value={{ firstname }}







             //////////////////////////////////////////////////////////////////////////

            //
            //     view('signup-success',[
            //         'title' => 'Create Account',
            //         'message' => "Dear $user->firstname $user->lastname, ... "
            //     ]);
            // }

        //     public static function signin($request=[]){
        //
        //         if (!empty($request)){
        //             //model User добавить метод findByLoginPassword($login,$password);
        //             // -> return Object of the user or null
        //             // используя ::all
        //             // if result == null -> view('signin',['error'=>''])
        //             // result == Object
        //
        //             // object --> $_SESSION[] (check if the Object is in $_SESSION (files/tmp ID -> ))
        //
        //
        //         }
        //
        //       view('signin',[
        //             'title' => 'Access your account'
        //         ]);
        //     }
      //   }





?>
