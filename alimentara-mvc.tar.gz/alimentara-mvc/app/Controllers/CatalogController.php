<?php
//error_reporting(E_ERROR);

  include 'app/Models/Product.php';
  include 'app/Models/Category.php';
  include 'app/Models/User.php';
  include 'app/Models/Cart.php';


   //все контроллеры статичные

   class CatalogController{


    public static function index(){

//////////////////////////////Product//////////////////////////////////////////////////////
   $products = new Product("Pizza",100,
   [
      "http://www.lapizzatreno.com/upload/pizza_thumb/pizza_image2376.png",
      "https://санчо-пицца.рф/files/products/396.200x200.jpg?7727fb0dd9438c06dbef487caf91dd08"
   ],
   20);
   $products->save();


   $products = new Product("Fish",80,
   [
      "http://eger38.ru/wp-content/uploads/2017/09/%D1%80%D1%8B%D0%B1%D0%B0-%D0%B3%D0%BE%D1%80-%D0%BA%D0%BE%D0%BFF62A9159-200x200.jpg",
      "http://www.peluxreal.cz/image/cache/data/024-200x200.jpg"
   ],
   15);
   $products->save();



   $products = new Product("Salat",60,
   [
      "http://sushi-na-dom.com/image/cache/catalog/sushi-na-dom/menu-header/salat-200x200.jpg",
      "http://pizza-itali.ru/wp-content/uploads/2015/04/cezar-200x200.jpg"
   ],
   17);
   $products->save();
//  $products::all();



/////////////////////////////CATEGORY/////////////////////////////////////////////////
   $categorie = new Category('Pizza');
   $categorie->save();
   $categorie = new Category('Fish');
   $categorie->save();
   $categorie = new Category('Salat');
   $categorie->save();

////////////////////////USER///////////////////////////////
   $user = new User("iurik", "123456","Pupcov", "Iurii", "iurii@mail.ru");
   $user->save();
////////////////////////////CART////////////////////////////////////////////
   $cart = new Cart(1000);
   $cart->save();
////////////////////////////////////////////////////////
     view('catalog',
      [
         'title'=>'Our products',
         'categories'=>$categorie::all(),
         'products'=>$products::all(),
         'footer'=>date('Y')
    ]);


        }


   }

 ?>
