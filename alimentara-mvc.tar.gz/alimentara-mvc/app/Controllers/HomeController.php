<?php
   //все контроллеры статичные
   class HomeController{

    public static function index(){
  //  echo view()->render('home.twig.html');
    view('home',['title'=>'Home page title']);

        }

   }


 ?>
