<?php
class User {
  public $firstname;
  public $lastname;
  public $login;
  public $password;
  public $email;
  static $salt = "lJKHED8934hlKlhad8K4nsd*Uhld";


  function __construct($login, $password,$firstname,$lastname,$email)
  {
    $this->firstname  = $firstname;
    $this->lastname   = $lastname;
    $this->login      = $login;
    $this->password   = hash("sha256", $password);
    $this->email      = $email;
  }

  public function save()
  {
    file_put_contents( "./database/user/".microtime().".json", json_encode ($this, JSON_PRETTY_PRINT) );
  }

}
?>
