<?php


  class Category
  {
      use GenUuid;

    public $name;

     function __construct($name)
     {
       $this->generateId();
       $this->name = $name;
     }



     public function save()
      {

//print_r($this->id);
file_put_contents( "./database/categories/".$this->id.".json",
 json_encode ($this, JSON_PRETTY_PRINT) );

      }


      public static function all(){
        $categories=[];
        $dir ='./database/categories';
        $f_list = array_slice(scandir( $dir ), 2);
        foreach ($f_list as $key => $value)
         {
           $content = file_get_contents("$dir/$value");
        $categories[] = json_decode( $content);

         }
         return $categories;
}

public static function load($category_id)
       {
        $file ='./database/categories/'.$category_id.'.json';
        $content = file_get_contents("$file");
        $category = json_decode($content);

        $c = new Category(
           $category->name
                          );
       $c->category_id=$category_id;
        return $c;
      }



public static function distribut()
{

  $c1 = new Category('mobiles') ;
  $c1->save();
  $c2 = new Category('mobiles2') ;
  $c2->save();
  $c3 = new Category('mobiles3') ;
  $c3->save();

  $dir = './database/products/';
  $files = array_slice(scandir( $dir ), 2);

  foreach ($files as $key => $value)
  {
      $filename = pathinfo($value, PATHINFO_FILENAME);
      $p1 = Product::load($filename);

     if ($key%3==0)
       {
         $p1->addCategory($c1);
         $p1->save();
       }

        else if ($key%3==1)
        {
          $p1->addCategory($c2);
          $p1->save();
        }
        else if ($key%3==2)
        {
          $p1->addCategory($c3);
          $p1->save();
        }
  
     }
 }




public static function clearAll()
{
$path = "./database/category/";
$files = glob("$path/*.json");
 foreach ($files as $csv_file)
    {
     $filepath = str_replace(" ", "\ ", $csv_file);
     echo $filepath . '<br/>';
     unlink($csv_file);
    }
}


}




 ?>
