<?php

include './app/Traits/GenUuid.php';
//include '/opt/lampp/htdocs/oop/alimentara-mvc/index.php';

  class Product
  {
    use GenUuid;
    public $id;
    public $name;
    public $price;
    public $photos;
    public $quantity;
    public $category_id;



     function __construct($name,$price,$photos=[],$quantity)
      {
       $this->generateId();
       $this->name = $name;
       $this->price = $price;
       $this->photos = $photos;
       $this->quantity= $quantity;
       $this->category_id  =0;
      }
      public function addCategory($category){
        $this->category_id =$category->id;
      }
      public function removeCategory(){
         $this->category_id  =0;
      }
      public function save()
       {
file_put_contents( "./database/products/".$this->id.".json", json_encode ($this, JSON_PRETTY_PRINT) );
       }



       public static function all(){
         $products=[];
         $dir ='./database/products';
         $f_list = array_slice(scandir( $dir ), 2);
         //print_r($f_list);
         foreach ($f_list as $key => $value)
          {

         $content = file_get_contents("$dir/$value");
         $products[] = json_decode($content);
           }
       return $products;
      }

  public static function clearAll()
   {
  $path = "./database/products/";
  $files = glob("$path/*.json");
    foreach ($files as $csv_file)
       {
        $filepath = str_replace(" ", "\ ", $csv_file);
        echo $filepath . '<br/>';
        unlink($csv_file);
       }
   }
   public function getCategory(){

     return $this->category_id;
   }


public static function load($id)
       {
        $file ='./database/products/'.$id.'.json';
        $content = file_get_contents("$file");
        $product = json_decode($content);

        $p = new Product(
          $product->name,
          $product->price,
          $product->photos,
          $product->quantity
                          );
        $p->id=$id;
        return $p;
      }

      public  function delete()
      {
          $id='9a80644e-9413-11e8-9dbd-2cd44493775b';
        if (unlink('./database/products/'.$id.'.json'))
      {
        echo "Файл удален";
        } else
        { echo "Ошибка при удалении файла"; }
       }

  }

?>
