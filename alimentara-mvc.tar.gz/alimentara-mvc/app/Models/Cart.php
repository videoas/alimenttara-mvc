<?php
class Cart {
  public $total;


  function __construct($total)
  {
    $this->total = $total;

  }

  public function save(){
    file_put_contents( "./database/cart/".microtime().".json", json_encode ($this, JSON_PRETTY_PRINT) );
  }

}
?>
